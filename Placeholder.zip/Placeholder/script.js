/* ==========================================================================
   OwoFarm — shared script
   Runs on both index.html and dashboard.html. Sections are guarded by
   checking whether the relevant element exists on the page.
   ========================================================================== */

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* --------------------------------------------------------------------------
   AUTH — Discord implicit-flow session management
   --------------------------------------------------------------------------
   After the user authorises on Discord, index.html's inline script stores
   the access token here. Everything else reads from AUTH so the session
   persists across page loads, back-navigation, and browser tabs until the
   token expires (~7 days) or the user explicitly logs out.
   -------------------------------------------------------------------------- */

const AUTH = {
  KEYS: {
    token:   "owofarm_token",
    expiry:  "owofarm_token_expiry",
    profile: "owofarm_profile",   // cached /users/@me response
  },

  /** Read back the token only if it hasn't expired yet. */
  token() {
    const t   = localStorage.getItem(this.KEYS.token);
    const exp = parseInt(localStorage.getItem(this.KEYS.expiry) || "0", 10);
    return t && Date.now() < exp ? t : null;
  },

  /** True when a non-expired token is present. */
  isValid() {
    return !!this.token();
  },

  /** Return the cached Discord user object, or null if nothing stored. */
  profile() {
    try {
      const raw = localStorage.getItem(this.KEYS.profile);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  /** Persist the Discord /users/@me response so we don't re-fetch it. */
  cacheProfile(user) {
    localStorage.setItem(this.KEYS.profile, JSON.stringify(user));
  },

  /** Wipe all session data — called on logout or when a token is rejected. */
  clear() {
    Object.values(this.KEYS).forEach((k) => localStorage.removeItem(k));
  },
};

/* --------------------------------------------------------------------------
   DISCORD API
   -------------------------------------------------------------------------- */

/**
 * Fetch the signed-in user's profile from Discord.
 * Returns the cached copy if available so we avoid an extra network round-trip
 * every time the dashboard is loaded.
 */
async function fetchDiscordUser(token) {
  const cached = AUTH.profile();
  if (cached) return cached;

  const res = await fetch("https://discord.com/api/v10/users/@me", {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    if (res.status === 401) AUTH.clear(); // token was revoked on Discord's side
    throw new Error(`Discord API returned ${res.status}`);
  }

  const user = await res.json();
  AUTH.cacheProfile(user);
  return user;
}

/** CDN URL for the user's avatar, falling back to a safe Discord default. */
function avatarUrl(user) {
  if (user.avatar) {
    return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`;
  }
  return "https://cdn.discordapp.com/embed/avatars/0.png";
}

/**
 * Prefer the user's display name (set independently of the unique username),
 * fall back to the unique username if it hasn't been set.
 */
function displayName(user) {
  return user.global_name || user.username;
}

/* --------------------------------------------------------------------------
   MOCK DATA LAYER
   --------------------------------------------------------------------------
   Billing and hero stats come from here until you wire up a real backend.
   The profile key below is only used as a last-resort fallback when the
   Discord API call fails.

   Swap fetchDashboardData() for:
     const res = await fetch('/api/dashboard/overview');
     return res.json();
   once your /api routes exist. The shape the rest of the UI expects is
   documented in README.md.
   -------------------------------------------------------------------------- */

const OWO_DATA = {
  profile: {
    username:  "—",
    avatarUrl: "https://cdn.discordapp.com/embed/avatars/0.png",
    balance:   128450,
  },
  heroStats: [
    { label: "Status",             value: "beta — just launched" },
    { label: "Accounts connected", value: "0 — could be yours first" },
    { label: "Build",              value: "v0.1.0" },
    { label: "Uptime tracking",    value: "starts once it's live" },
  ],
  transactions: [
    { date: "26 Jun 2026", desc: "Top up saldo",  amount:  50000 },
    { date: "24 Jun 2026", desc: "Pembelian key", amount: -10000 },
    { date: "20 Jun 2026", desc: "Top up saldo",  amount: 100000 },
    { date: "15 Jun 2026", desc: "Pembelian key", amount: -10000 },
  ],
};

async function fetchDashboardData() {
  return Promise.resolve(OWO_DATA);
}

/* --------------------------------------------------------------------------
   Mobile nav toggle (landing page)
   -------------------------------------------------------------------------- */

const navToggle = document.querySelector(".nav-toggle");
const navLinks  = document.querySelector(".nav-links");
if (navToggle && navLinks) {
  navToggle.addEventListener("click", () => {
    const isOpen = navLinks.style.display === "flex";
    navLinks.style.display = isOpen ? "none" : "flex";
  });
}

/* --------------------------------------------------------------------------
   Sidebar toggle (dashboard, mobile)
   -------------------------------------------------------------------------- */

const sidebar        = document.querySelector(".sidebar");
const sidebarToggle  = document.querySelector(".sidebar-toggle");
const sidebarOverlay = document.querySelector(".sidebar-overlay");

function closeSidebar() {
  sidebar?.classList.remove("open");
  sidebarOverlay?.classList.remove("open");
}

if (sidebar && sidebarToggle) {
  sidebarToggle.addEventListener("click", () => {
    sidebar.classList.toggle("open");
    sidebarOverlay?.classList.toggle("open");
  });
  sidebarOverlay?.addEventListener("click", closeSidebar);
}

/* --------------------------------------------------------------------------
   Hero stats renderer (landing page)
   -------------------------------------------------------------------------- */

function renderHeroStats(stats, container) {
  if (!container) return;
  container.innerHTML = stats
    .map(
      (s) => `
      <div class="term-stat-row">
        <span class="term-stat-label">${s.label}</span>
        <span class="term-stat-value mono">${s.value}</span>
      </div>`
    )
    .join("");
}

/* --------------------------------------------------------------------------
   Hero terminal (landing page)
   -------------------------------------------------------------------------- */

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function typeText(el, text, speed = 28) {
  if (reduceMotion) { el.textContent += text; return; }
  for (const char of text) {
    el.textContent += char;
    await sleep(speed);
  }
}

async function initHeroTerminal(heroStats) {
  const body = document.getElementById("termBody");
  if (!body) return;

  const cmdLine = document.createElement("div");
  cmdLine.className = "term-line";
  cmdLine.innerHTML = `<span class="term-prompt-user">kestrel</span>@<span class="term-prompt-path">termux</span>:~/owofarm$ <span class="term-cmd"></span>`;
  body.appendChild(cmdLine);
  await typeText(cmdLine.querySelector(".term-cmd"), "owofarm status --live", 30);
  await sleep(250);

  const headline = document.createElement("div");
  headline.className = "term-headline";
  headline.innerHTML = `<span class="hash"># </span>Your OwO grind, <span class="accent">on autopilot</span>`;
  body.appendChild(headline);

  const descLines = [
    "Hunts, battles, and daily claims run on the schedule you set.",
    "Every catch and drop shows up here the moment it happens.",
  ];
  for (const line of descLines) {
    const d = document.createElement("div");
    d.className = "term-desc";
    d.innerHTML = `<span class="arrow">// </span>${line}`;
    body.appendChild(d);
  }

  const fetching = document.createElement("div");
  fetching.className = "term-fetching";
  fetching.textContent = "checking status...";
  body.appendChild(fetching);
  if (!reduceMotion) await sleep(600);

  const statsEl = document.createElement("div");
  statsEl.className = "term-stats";
  body.appendChild(statsEl);
  renderHeroStats(heroStats, statsEl);

  const nextPrompt = document.createElement("div");
  nextPrompt.className = "term-line";
  nextPrompt.style.marginTop = "16px";
  nextPrompt.innerHTML = `<span class="term-prompt-user">kestrel</span>@<span class="term-prompt-path">termux</span>:~/owofarm$ <span class="term-cursor"></span>`;
  body.appendChild(nextPrompt);
}

/* --------------------------------------------------------------------------
   Dashboard: profile rendering
   -------------------------------------------------------------------------- */

function renderProfile(profile) {
  document.querySelectorAll("[data-profile-name]").forEach((el) => {
    el.textContent = profile.username;
  });
  document.querySelectorAll("[data-profile-avatar]").forEach((el) => {
    el.src = profile.avatarUrl;
    el.alt = profile.username;
  });
}

/* --------------------------------------------------------------------------
   Dashboard: view switcher
   -------------------------------------------------------------------------- */

const VIEW_META = {
  overview: { title: "Overview",  subtitle: "Cek status key kamu di sini." },
  key:      { title: "Key",       subtitle: "Key ini menghubungkan bot kamu ke dashboard ini." },
  billing:  { title: "Billing",   subtitle: "Saldo dan riwayat transaksi kamu." },
  settings: { title: "Settings",  subtitle: "Pengaturan akun." },
  support:  { title: "Support",   subtitle: "Butuh bantuan? Kami siap membantu." },
};

function showView(view) {
  document.querySelectorAll(".dash-view").forEach((sec) => {
    sec.hidden = sec.dataset.view !== view;
  });
  document.querySelectorAll(".side-nav .side-link").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.view === view);
  });
  const meta    = VIEW_META[view] || {};
  const titleEl = document.getElementById("viewTitle");
  const subEl   = document.getElementById("viewSubtitle");
  if (titleEl) titleEl.textContent = meta.title    || "";
  if (subEl)   subEl.textContent   = meta.subtitle || "";
  closeSidebar();
}

function initSidebarNav() {
  document.querySelectorAll(".side-nav .side-link[data-view]").forEach((btn) => {
    btn.addEventListener("click", () => showView(btn.dataset.view));
  });
}

/* --------------------------------------------------------------------------
   Dashboard: key view
   -------------------------------------------------------------------------- */

function generateMockKey() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const group = () =>
    Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  return `OWOFARM-${group()}-${group()}-${group()}`;
}

function initKeyView() {
  const valueEl  = document.getElementById("keyValue");
  const copyBtn  = document.getElementById("copyKeyBtn");
  const regenBtn = document.getElementById("regenerateKeyBtn");
  if (!valueEl) return;

  // TODO: replace with fetch('/api/key') once the backend exists
  valueEl.textContent = generateMockKey();

  copyBtn?.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(valueEl.textContent);
      const original = copyBtn.textContent;
      copyBtn.textContent = "Copied!";
      setTimeout(() => (copyBtn.textContent = original), 1500);
    } catch { /* clipboard unavailable — fail silently */ }
  });

  regenBtn?.addEventListener("click", () => {
    // TODO: replace with fetch('/api/key/regenerate', { method: 'POST' })
    valueEl.textContent = generateMockKey();
  });
}

/* --------------------------------------------------------------------------
   Dashboard: billing
   -------------------------------------------------------------------------- */

function formatRupiah(n) {
  return "Rp " + Math.abs(n).toLocaleString("id-ID");
}

function renderBilling(profile, transactions) {
  const balanceEl = document.getElementById("billingBalance");
  if (balanceEl) balanceEl.textContent = formatRupiah(profile.balance);

  const tbody = document.getElementById("billingBody");
  if (!tbody) return;
  tbody.innerHTML = transactions
    .map(
      (t) => `
      <tr>
        <td>${t.date}</td>
        <td>${t.desc}</td>
        <td class="col-reward" style="color:${t.amount >= 0 ? "var(--success)" : "var(--text-dim)"}">
          ${t.amount >= 0 ? "+" : "-"}${formatRupiah(t.amount)}
        </td>
      </tr>`
    )
    .join("");
}

/* --------------------------------------------------------------------------
   BOOT
   -------------------------------------------------------------------------- */

document.addEventListener("DOMContentLoaded", async () => {
  const onDashboard = !!document.querySelector(".dash-shell");
  const onLanding   = !!document.getElementById("termBody");

  /* ======== LANDING PAGE ======== */
  if (onLanding) {
    const data = await fetchDashboardData();
    await initHeroTerminal(data.heroStats);

    // Intercept every "Get Started" / "Get started free" link.
    // If the visitor already has a valid session, skip OAuth entirely and
    // go straight to the dashboard. Otherwise let the href proceed normally
    // — the user will authorise on Discord and come back to this page.
    document.querySelectorAll('a[href*="discord.com/oauth2"]').forEach((link) => {
      link.addEventListener("click", (e) => {
        if (AUTH.isValid()) {
          e.preventDefault();
          window.location.href = "dashboard.html";
        }
      });
    });

    return; // nothing else on this page needs to run
  }

  /* ======== DASHBOARD PAGE ======== */
  if (onDashboard) {
    const token = AUTH.token();

    // Guard: if the inline script somehow didn't redirect (e.g. JS was
    // deferred or the storage was cleared mid-session), redirect now.
    if (!token) {
      window.location.replace("index.html");
      return;
    }

    const data = await fetchDashboardData();

    try {
      // Fetch the real Discord profile (from cache or the API)
      const user = await fetchDiscordUser(token);
      renderProfile({
        username:  displayName(user),
        avatarUrl: avatarUrl(user),
        balance:   data.profile.balance, // still mock until the backend exists
      });
    } catch (err) {
      // If the API call fails (network error, revoked token, etc.), fall back
      // to the neutral placeholder so the UI stays functional.
      console.warn("Could not load Discord profile:", err);
      renderProfile(data.profile);
    }

    renderBilling(data.profile, data.transactions);
    initKeyView();
    initSidebarNav();
    showView("overview");

    // Logout: wipe the session, then navigate to the landing page.
    // data-logout is on the "Log out" anchor in dashboard.html.
    document.querySelector("[data-logout]")?.addEventListener("click", (e) => {
      e.preventDefault();
      AUTH.clear();
      window.location.replace("index.html");
    });
  }
});