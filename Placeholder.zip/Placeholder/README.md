# OwoFarm frontend

Static frontend: a public landing page (`index.html`) and an account/key/billing dashboard (`dashboard.html`), sharing one stylesheet and one script file. No build step — open either HTML file directly, or serve the folder with any static file server / your backend's templating engine.

## Files

```
index.html       Public landing page (hero, features, how-it-works, CTA)
dashboard.html    Account dashboard (Overview, Key, Billing, Settings, Support)
styles.css        Shared design tokens + layout + components
script.js         Shared behavior: hero terminal animation, mock data, rendering
```

## How login works

There's no key-entry form anymore. The flow is:

1. On the landing page, the **Get started free** button sends the visitor straight into Discord's OAuth authorize screen, scoped to `identify`.
2. Discord redirects back to the `redirect_uri` you registered (currently `https://owohelper.vercel.app/`, i.e. back to `index.html`) with a `?code=...` query parameter.
3. A small inline script at the top of `index.html` checks for that `code` on load and immediately forwards the browser to `dashboard.html` (Overview), carrying the query string along. This is just a navigation convenience — it does **not** exchange the code for anything.
4. **The actual code exchange has to happen on your backend, never in this frontend.** Exchanging it for an access token requires your app's client secret, which must never ship in client-side JS. Your server should read the `code` (whether it intercepts the redirect before `index.html`, or reads it from `dashboard.html`'s URL), call Discord's token endpoint, and create a real session.
5. `dashboard.html` itself assumes the visitor is already authenticated by the time they land on it — there's no client-side gate. Protect the route server-side the same way you'd protect any other authenticated page.

## What's on the dashboard

- **Overview** — currently empty (an open container, `#overviewGrid`, ready for whatever you want to put there).
- **Key** — an auto-generated key for this account, with Copy and Regenerate. This key is something the visitor pastes into *their own* bot/script config so it can report back to your backend — it's an output, not a password they type in.
- **Billing** — balance (Rupiah) and transaction history. This is the only place balance/transactions appear anywhere in the dashboard.
- **Settings / Support** — static placeholders for now.

There's intentionally no "Accounts", "Farming status", or "History" page — none of that lives in the dashboard anymore.

The sidebar profile shows a real avatar image (`<img data-profile-avatar>`) rather than initials. It's currently set to Discord's public default-avatar asset as a placeholder — swap `profile.avatarUrl` in `OWO_DATA` for the real one once OAuth is wired up: `https://cdn.discordapp.com/avatars/{userId}/{avatarHash}.png`.

## How data flows in right now

Everything the dashboard shows comes from one object, `OWO_DATA`, near the top of `script.js`. A single function, `fetchDashboardData()`, returns it. That's the one place you need to change:

```js
// script.js — replace this:
async function fetchDashboardData() {
  return Promise.resolve(OWO_DATA);
}

// with something like this:
async function fetchDashboardData() {
  const res = await fetch('/api/dashboard/overview', { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to load dashboard data');
  return res.json();
}
```

Two more spots have mock behavior marked with `// TODO` in `script.js`:

- `initKeyView()` — generates a fake key client-side and "regenerates" it with another random string. Replace both with real calls to your backend (`GET /api/key`, `POST /api/key/regenerate`) so the key is actually tied to the signed-in account and persists.
- The Discord OAuth `code` → session exchange described above — this one isn't in `script.js` at all, since it can't safely run in the browser. It belongs in your backend.

## Suggested API surface

| Method | Path | Used for |
|---|---|---|
| `GET`  | `/api/user/profile` | username, avatar initials |
| `GET`  | `/api/key` | the signed-in account's current key |
| `POST` | `/api/key/regenerate` | rotate the key, return the new one |
| `GET`  | `/api/billing` | balance + transaction history |

If your backend already organizes things into `cogs`, `utils`, and a `setting.json`-style config, the cleanest seam is usually a thin API layer (Flask/FastAPI/Express route) that reads from your existing config/state and returns JSON in the shapes above.

## Customizing the look

All colors, type, spacing, and radii are CSS variables at the top of `styles.css` (`:root { ... }`). Changing the two accent colors (`--cyan`, `--blue`) re-themes buttons, the active nav state, and the hero terminal glow consistently, since everything pulls from those two variables.
